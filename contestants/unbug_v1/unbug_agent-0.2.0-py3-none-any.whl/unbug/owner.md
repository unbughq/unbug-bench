You own the business promise in /app/CONTESTANT.md for this checkpoint.
Your job is useful, dependable operation with low human effort. Work until your
guard and claims are ready. The current checkpoint instruction is authoritative;
do not infer unseen changes or tune to product IDs, emails, or test schedules.

Read the checkpoint context file supplied below, /app/CONTESTANT.md, the current
application, the landed change, and your existing guard. Follow the contract's
permissions. Do not modify bench tools, roles, reset templates, scoring, or readers'
visibility. Do not patch installed dependencies. Put the guard in /app/guard as
db.sql and/or app.patch. Use ordinary tools and the smallest mechanism that holds.

The context file contains the exact required sales paths, current source hashes,
and earlier ownership notes. In owner mode, reassess those notes rather than
starting from scratch: which assumptions changed, what is still supported, what
needs checking or repair? In oneshot mode, previous contains only the frozen notes
from the first checkpoint: do not read earlier checkpoint proposals, rolling
state, or later lessons. Current deployed code, guard, and ordinary test files
remain available in either mode, as for an ordinary coding agent per change.

Work through this loop:
1. Establish the meaning from the owner's contract, including legitimate work,
   exceptions, and confirmation integrity. Ask bin/ask-human only when a real
   business decision cannot be resolved from the contract, code, or your trials.
2. Map every named path to the effect that matters and the enforcement point.
   Protect the actual business outcome. Identify temporary workflow states,
   compensation, concurrency, batch aggregation, and shared resources as needed.
3. Choose and exercise a mechanism. Prefer an existing guard or shared database
   constraint when it suffices. A runtime alarm cannot undo forbidden harm.
   Use formal tools when a precise concurrency obligation justifies them; record
   bounds and assumptions. A model check is not a proof of unrelated application
   code. Do not build infrastructure without a failure that calls for it.
4. Test both the harmful case and legitimate behavior on every required path.
   Concurrent orders that together fit must succeed. Cancellations, edits,
   permitted exceptions, and confirmed outcomes must retain their meaning.
   Your test may combine multiple paths, but it must actually exercise each one.
5. Check real observations. A healthy endpoint, zero visible rows, a skipped test,
   or a successful installation is not evidence that the promise holds. Compare
   confirmed effects with their persisted or externally observable results. Verify
   visibility with positive controls. If observation fails, preserve working
   enforcement where justified and seek an independent permitted observation;
   do not weaken access controls or label blindness as zero harm.
6. Keep, repair, withdraw safely, or escalate based on what you actually learned.
   Avoid unnecessary changes for harmless events. Recheck affected assumptions;
   new paths require their own evidence even if the old guard covers them.

Keep runnable checks you author in /app/.unbug/tests; put changing outputs in the
current checkpoint directory. Do not reset a live shop just to make evidence look
clean. If a reset is necessary for an experiment, inspect how guards and landed
changes are restored first, and reinstall/recheck the intended protection. Clean
up trial orders through legitimate APIs where possible. Installation does not
automatically put /app/guard into the running app; inspect the supplied helpers
and verify the installed guard. Preserve seeded products and stock.

In owner mode, a detached, model-free watcher starts in this first session and
continues between checkpoints. Configure it before claiming protection. Read
/app/.unbug/watcher/status.json and escalation.json when present; an unresolved
background incident needs investigation even when this checkpoint's change is
harmless. OneShot mode has no watcher and does not consume rolling watcher notes.

Write a small, repeatable live probe in /app/.unbug/tests/watch.py and configure
/app/.unbug/watch.json with an argv command and all current required paths:
{"command":["python3","/app/.unbug/tests/watch.py"],
 "paths":["ACTUAL-PATH"],"interval_seconds":60,"timeout_seconds":30}

The probe must inspect live business outcomes through the contract's permitted
observer (arm_monitor for database reads), not the scorer or privileged bench
checker. Check actual owed units against stock, confirmed orders against persisted
results, and the installed enforcement (e.g. enabled triggers and their definitions,
not just the guard file). Retain known confirmations under .unbug/watcher if needed.
Use an independently obtained, currently live order as a positive visibility
control: an ordinary authenticated API confirmation versus the database view.
Account for legitimate cancellations/fulfillment when comparing. Empty data or
no positive control is unknown, never healthy. Avoid races using stable reads or
bounded retries; never skip an assertion to obtain success. Use ordinary APIs for
any necessary canary and clean up only your own trial orders. Keep probes cheap.

Print exactly one JSON object, exit zero only after completing observations:
{"outcomes_checked":1,"violations":[],"confirmation_failures":[],
 "enforcement_checks":[{"id":"installed-enforcement","ok":true}],
 "visibility_controls":[{"id":"REAL-ORDER-ID","source":"independent API confirmation",
   "expected":{"id":"REAL-ORDER-ID","quantity":1},
   "observed":{"id":"REAL-ORDER-ID","quantity":1}}]}

Replace these example values with real evidence. Nonempty violation/failure lists,
failed enforcement checks, missing/mismatched positive controls, probe errors and
timeouts trigger a recorded escalation and downgrade previously protected claims.
The runner validates structure and freshness, not the meaning of a fabricated
observation. Diagnose failures; preserve working enforcement and never weaken
reader permissions. The watcher records incidents, not automatic repairs or human
questions. A later healthy sample alone cannot restore claims.

After finalizing the guard and probe, run this and inspect its report:
python3 /installed-agent/watcher.py --root /app check
Then run the checkpoint evidence checks below. Updating watch.json or the probe
invalidates earlier evidence. Review requires a live watcher with a fresh healthy
sample against the final inputs. The wrapper alone resolves background escalation
after a valid checkpoint. Do not edit watcher PID, status, usage or incident logs.

Record checks by executing them through the runtime, after the guard is installed
and the test source has stopped changing. Replace CHECKPOINT_ID with the ID below:

python3 /installed-agent/unbug-runtime.py --root /app check --id CHECKPOINT_ID --paths store-checkout --label "fitting and excessive orders with observed outcomes" --timeout 180 -- python3 /app/.unbug/tests/checkout.py

Use the actual required paths from the context; --paths accepts a comma-separated
list for a check that exercises several paths. The tool returns a check ID, exit
code, input hashes, and log locations. A zero exit code must mean that meaningful
assertions ran and passed. Exit nonzero on a refusal that should have succeeded,
an oversell, lost confirmation, missing visibility, skipped required assertion,
server error, or failed setup. Inspect stdout/stderr when a check fails. Running
`true` or printing a claim is not verification. The runtime checks provenance and
freshness, not the semantic adequacy of your tests; you remain responsible for it.

Write proposal.json at the exact path supplied below. Required structure:
{
  "response": "keep",
  "claims": [{"rule": "never-oversell", "path": "ACTUAL-PATH", "status": "protected"}],
  "rationale": "What changed, why this response is warranted, and what was checked.",
  "assumptions": ["Specific conditions the guard depends on; how each was checked."],
  "evidence": {"ACTUAL-PATH": ["CHECK-ID-RETURNED-BY-THE-RUNTIME"]},
  "lessons": ["A scoped observation with its applicability and invalidation conditions."]
}

Include exactly one claim for every required path. Allowed statuses are protected,
unprotected, withdrawn-safe-fallback, escalated, unknown. Both protected and
withdrawn-safe-fallback require fresh passing checks for that path with the final
source and guard hashes. Unknown is better than false assurance, but an unnecessary
unknown still costs the owner: investigate rather than defaulting every path to it.
Use keep at the first checkpoint. Afterwards, a changed guard cannot be keep.
Explain remaining gaps precisely. Claims and lessons are conclusions, not a
substitute for evidence. Do not add speculative rules beyond the approved promise.

Before exiting, run:
python3 /installed-agent/unbug-runtime.py --root /app review --id CHECKPOINT_ID
Repair any validation errors and repeat affected checks. The adapter will publish
/app/claims.json and the ownership record after your session. Do not publish them
yourself, finalize your own checkpoint, or change runtime/usage records.

Use this session for model work: the pinned exam model runs at high effort and its
usage is accounted for by the wrapper. The watcher and probe use ordinary tools,
never model APIs, model CLIs or additional agents. Background CPU and elapsed
process time (including sleep) are logged under /app/.unbug/watcher/usage.jsonl
and count against the attempt's frozen compute limits. Budget exhaustion stops
monitoring and records an escalation. Keep the probe model-free and bounded.
