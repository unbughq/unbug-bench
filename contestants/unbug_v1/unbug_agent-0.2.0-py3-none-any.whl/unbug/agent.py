"""Harbor 0.24 adapter: reuse Claude Code; own the checkpoint lifecycle."""
import asyncio
import json
import math
from pathlib import Path
import shlex
import tempfile
import uuid

from pydantic import Field
from harbor.agents.capabilities import AgentCapabilities
from harbor.agents.installed.claude_code import ClaudeCode, ClaudeCodeOptions


class UnbugOptions(ClaudeCodeOptions):
    version: str | None = Field(default="2.1.299", description="Pinned Claude Code version; match across comparison arms.")
    allow_paid_runs: bool = Field(default=False, description="Explicit operator approval for paid model execution.")
    attempt_budget_usd: float = Field(default=150.0, gt=0, description="Total budget across all checkpoints; frozen per attempt.")
    watcher_cpu_budget_seconds: float = Field(default=300.0, gt=0, description="Background CPU seconds across the attempt, including probes.")
    watcher_wall_budget_seconds: float = Field(default=86400.0, gt=0, description="Background process wall seconds across the attempt, including idle time.")


class UnbugAgent(ClaudeCode):
    """Fresh coding sessions with rolling, evidence-backed ownership records."""
    options_model = UnbugOptions
    mode = "owner"
    capabilities = AgentCapabilities(atif=True, native_config=True, skills=True, mcp_servers=True)
    runtime = "/installed-agent/unbug-runtime.py"

    @staticmethod
    def name():
        return "unbug"

    def __init__(self, *args, **kwargs):
        # Harbor forwards its constructor's version=None into the options model,
        # which overrides a subclass field default unless supplied explicitly.
        kwargs["version"] = kwargs.get("version") or UnbugOptions.model_fields["version"].default
        kwargs.setdefault("reasoning_effort", "high")
        super().__init__(*args, **kwargs)
        if self.options.reasoning_effort != "high":
            raise ValueError("The exam configuration requires high reasoning effort")
        if self.options.fallback_model:
            raise ValueError("Fallback models would violate the exam's pinned-model condition")
        if not self.model_name or self.model_name.rsplit("/", 1)[-1] in {"opus", "sonnet", "haiku", "latest"}:
            raise ValueError("Supply the exam's full, pinned model ID with --model")
        if not math.isfinite(self.options.attempt_budget_usd):
            raise ValueError("Attempt budget must be finite")
        if not all(math.isfinite(value) for value in (self.options.watcher_cpu_budget_seconds, self.options.watcher_wall_budget_seconds)):
            raise ValueError("Watcher compute budgets must be finite")
        if self.options.max_budget_usd is not None:
            limit = float(self.options.max_budget_usd)
            if not math.isfinite(limit) or limit <= 0:
                raise ValueError("Per-call budget must be positive and finite")
        # Avoid unaccounted secondary models. Ordinary shell/test/database tools remain available.
        self.options.disallowed_tools = ",".join(filter(None, [self.options.disallowed_tools, "Agent", "Task"]))

    async def setup(self, environment):
        await super().setup(environment)
        await self._upload_agent_owned_file(environment, Path(__file__).with_name("runtime.py"), self.runtime)
        await self._upload_agent_owned_file(environment, Path(__file__).with_name("watcher.py"), "/installed-agent/watcher.py")

    async def _upload_instruction(self, environment, instruction, target):
        with tempfile.TemporaryDirectory(prefix="unbug-instruction-") as directory:
            source = Path(directory) / "instruction.txt"
            source.write_text(instruction)
            await self._upload_agent_owned_file(environment, source, target)

    async def run(self, instruction, environment, context):
        if not self.options.allow_paid_runs:
            raise PermissionError("Paid runs are disabled. After founder approval, pass --agent-kwarg allow_paid_runs=true.")
        identifier = uuid.uuid4().hex
        # DinD mounts /tmp inside its own namespace: docker cp can write below
        # that mount while exec reads above it. Keep uploaded files together.
        instruction_path = f"/installed-agent/unbug-instruction-{identifier}.txt"
        await self._upload_instruction(environment, instruction, instruction_path)
        command = ["python3", self.runtime, "--root", "/app", "prepare", "--id", identifier,
                   "--instruction", instruction_path, "--mode", self.mode, "--model", self.model_name,
                   "--budget", str(self.options.attempt_budget_usd),
                   "--watcher-cpu-budget-seconds", str(self.options.watcher_cpu_budget_seconds),
                   "--watcher-wall-budget-seconds", str(self.options.watcher_wall_budget_seconds)]
        if self.mode == "owner":
            command.append("--watcher")
        prepared = await self.exec_as_agent(environment, shlex.join(command), cwd="/app")
        info = json.loads(prepared.stdout)
        prompt = Path(__file__).with_name("owner.md").read_text()
        prompt += (f"\n\nCheckpoint: {identifier}\nMode: {self.mode}\n"
                   f"Read your current context at {info['context']}.\n"
                   f"Write your final proposal at {info['proposal']}.\n\n"
                   f"CURRENT OWNER INSTRUCTION\n{instruction}\n")
        old_budget = self.options.max_budget_usd
        limit = float(old_budget) if old_budget is not None else info["remaining_usd"]
        if not math.isfinite(limit) or limit <= 0:
            raise ValueError("Per-call budget must be positive and finite")
        self.options.max_budget_usd = str(min(limit, info["remaining_usd"]))
        succeeded = False
        usage_log = f"/app/.unbug/checkpoints/{identifier}/missing-model-log"
        try:
            if self.mode == "owner":
                started = await self.exec_as_agent(environment, "python3 /installed-agent/watcher.py --root /app start", cwd="/app")
                if started.return_code != 0:
                    raise RuntimeError(f"Watcher startup failed: {started.stdout}\n{started.stderr}")
            log = str(self.environment_logs_dir / "claude-code.txt")
            clear = "from pathlib import Path; p=Path(" + repr(log) + "); p.parent.mkdir(parents=True,exist_ok=True); p.write_text('')"
            await self.exec_as_agent(environment, shlex.join(["python3", "-c", clear]), cwd="/app")
            usage_log = log
            await super().run(prompt, environment, context)
            succeeded = True
        finally:
            self.options.max_budget_usd = old_budget
            command = ["python3", self.runtime, "--root", "/app", "finish", "--id", identifier,
                       "--usage-log", usage_log]
            if not succeeded:
                command.append("--failed")
            result = await asyncio.wait_for(asyncio.shield(environment.exec(
                command=shlex.join(command), cwd="/app", timeout_sec=15)), timeout=20)
            try:
                self.logs_dir.mkdir(parents=True, exist_ok=True)
                (self.logs_dir / "unbug-result.json").write_text(result.stdout)
            except (OSError, TypeError):
                self.logger.exception("Could not retain Unbug's checkpoint result in Harbor logs")
            if result.return_code != 0 and succeeded:
                raise RuntimeError(f"Unbug checkpoint rejected: {result.stdout}\n{result.stderr}")

    def populate_context_post_run(self, context):
        super().populate_context_post_run(context)
        path = self.logs_dir / "unbug-result.json"
        if not path.exists():
            return
        try:
            usage = json.loads(path.read_text())["usage"]
            if not isinstance(usage, dict) or "cost_usd" not in usage:
                raise ValueError("Missing provider accounting")
        except (OSError, ValueError, KeyError, TypeError):
            self.logger.warning("Unbug result accounting is missing or malformed; preserving Harbor's native metrics")
            return
        if context.cost_usd is None:
            context.cost_usd = usage["cost_usd"]
        # Preserve unknowns if provider fields are absent. Harbor's native
        # trajectory remains the preferred source when it converted successfully.
        tokens = usage.get("usage")
        if isinstance(tokens, dict):
            names = ("input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens")
            if all(isinstance(tokens.get(k, 0), int) and tokens.get(k, 0) >= 0 for k in names):
                if context.n_input_tokens is None and "input_tokens" in tokens:
                    context.n_input_tokens = sum(tokens.get(k, 0) for k in names if k != "output_tokens")
                if context.n_output_tokens is None and "output_tokens" in tokens:
                    context.n_output_tokens = tokens["output_tokens"]
                if context.n_cache_tokens is None and "cache_read_input_tokens" in tokens:
                    context.n_cache_tokens = tokens["cache_read_input_tokens"]


class OneShotAgent(UnbugAgent):
    """Frozen notes; paired C0 uses an operator fork of C's establishment output."""
    mode = "oneshot"

    @staticmethod
    def name():
        return "unbug-oneshot"
