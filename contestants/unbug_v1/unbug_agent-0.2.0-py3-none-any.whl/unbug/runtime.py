"""Durable checkpoints, executed checks, honest claims, and usage accounting.

This runtime executes no model calls. The Harbor adapter supplies the coding agent.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import time
import uuid

STATUSES = {"protected", "unprotected", "withdrawn-safe-fallback", "escalated", "unknown"}
RESPONSES = {"keep", "repair", "withdraw", "escalate"}
IGNORED = {"node_modules", ".git", ".medusa", "__pycache__", ".cache"}


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def file_hash(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def read(path):
    return json.loads(path.read_text())


def checkpoint(root, name):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,79}", name):
        raise ValueError("Invalid checkpoint identifier")
    return root / ".unbug/checkpoints" / name


@contextmanager
def lock(root):
    directory = root / ".unbug"
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / ".lock").open("a") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


def fingerprint(root):
    """Public application/change inputs and guard; never traverse dependencies or symlinks."""
    files = [root / "CONTESTANT.md", root / ".unbug/watch.json"]
    for directory in (root / "projects", root / "changes", root / "guard", root / ".unbug/tests"):
        if directory.is_symlink():
            raise ValueError(f"Fingerprint input is a symlink: {directory}")
        if directory.exists():
            for parent, directories, names in os.walk(directory, followlinks=False):
                directories[:] = [d for d in directories if d not in IGNORED]
                for child in directories:
                    if (Path(parent) / child).is_symlink():
                        raise ValueError(f"Fingerprint input is a symlink: {Path(parent) / child}")
                files.extend(Path(parent) / name for name in names)
    result = {}
    for path in sorted(files):
        if path.is_symlink():
            raise ValueError(f"Fingerprint input is a symlink: {path}")
        if path.exists():
            if not path.is_file():
                raise ValueError(f"Fingerprint input is not a regular file: {path}")
            result[str(path.relative_to(root))] = file_hash(path)
    return result


def guard_hash(root):
    files = {p.name: file_hash(p) for p in sorted((root / "guard").glob("*"))
             if p.is_file() and p.name in {"db.sql", "app.patch"}}
    return digest(files)


def required_paths(instruction):
    lines = instruction.splitlines()
    for index, line in enumerate(lines):
        match = re.search(r"(?:one claim per sales path|\bpaths(?: now)?)\s*:?\s*(?=`)", line, re.I)
        if match:
            text = line[match.end():]
            while text.rstrip().endswith(",") and index + 1 < len(lines):
                index += 1
                text += " " + lines[index].strip()
            paths = re.findall(r"`([a-z][a-z0-9-]*)`", text)
            if paths and len(paths) == len(set(paths)):
                return paths
    raise ValueError("Cannot identify required sales paths in the checkpoint instruction")


def usage_total(root):
    total = 0.0
    for path in (root / ".unbug/usage.jsonl", root / ".unbug/watcher/usage.jsonl"):
        if not path.exists():
            continue
        for line in path.read_text().splitlines():
            item = json.loads(line)
            cost = item.get("cost_usd")
            if isinstance(cost, bool) or not isinstance(cost, (int, float)) or not math.isfinite(cost) or cost < 0:
                raise ValueError("A previous model call has unknown cost; reconcile usage before another paid run")
            total += cost
    return total


def watcher_module():
    if __package__:
        from . import watcher
    else:
        import watcher
    return watcher


def prepare(root, name, instruction, mode, model, budget, watcher_enabled=False,
            watcher_cpu_budget_seconds=300, watcher_wall_budget_seconds=86400):
    directory = checkpoint(root, name)
    if directory.exists():
        raise ValueError("Checkpoint already exists; refusing to duplicate a model call")
    # Even malformed new instructions must not leave a prior protected report
    # looking current. Without valid path names, absence is safer than invention.
    (root / "claims.json").unlink(missing_ok=True)
    if not math.isfinite(budget) or budget <= 0:
        raise ValueError("Attempt budget must be positive and finite")
    for limit in (watcher_cpu_budget_seconds, watcher_wall_budget_seconds):
        if isinstance(limit, bool) or not math.isfinite(limit) or limit <= 0:
            raise ValueError("Watcher compute budgets must be positive and finite")
    config = {"version": 2, "mode": mode, "model": model, "attempt_budget_usd": budget,
              "watcher_enabled": watcher_enabled and mode == "owner",
              "watcher_cpu_budget_seconds": watcher_cpu_budget_seconds,
              "watcher_wall_budget_seconds": watcher_wall_budget_seconds}
    config_path = root / ".unbug/config.json"
    if config_path.exists() and read(config_path) != config:
        raise ValueError("Mode, model, and attempt budget are frozen for an attempt; use a fresh workspace")
    paths = required_paths(instruction)
    spent = usage_total(root)
    if spent >= budget:
        raise ValueError("Attempt budget exhausted")
    for previous in (root / ".unbug/checkpoints").glob("*/context.json"):
        if not (previous.parent / "result.json").exists():
            raise ValueError("An earlier checkpoint is unfinished; reconcile it before another model call")
    snapshot = fingerprint(root)
    state_path = root / ".unbug" / ("state.json" if mode == "owner" else "frozen.json")
    previous = read(state_path) if state_path.exists() else None
    context = {"id": name, "mode": mode, "created_at": now(), "instruction": instruction,
               "required_paths": paths, "inputs": snapshot, "guard_before": guard_hash(root),
               "previous": previous, "spent_usd": spent, "remaining_usd": budget - spent}
    if config["watcher_enabled"]:
        path = root / ".unbug/watcher"
        context["watcher"] = {"status": read(path / "status.json") if (path / "status.json").exists() else None,
                              "escalation": read(path / "escalation.json") if (path / "escalation.json").exists() else None}
    write(directory / "context.json", context)
    write(config_path, config)
    write(root / ".unbug/current.json", {"checkpoint": name})
    # An interrupted run must not leave yesterday's protected claims at today's checkpoint.
    fallback(root, paths, "keep")
    return {"checkpoint": name, "context": str(directory / "context.json"),
            "proposal": str(directory / "proposal.json"), "remaining_usd": budget - spent}


def fallback(root, paths, response):
    write(root / "claims.json", {"response": response,
          "claims": [{"rule": "never-oversell", "path": path, "status": "unknown"} for path in paths]})


def fork_oneshot(root):
    """Convert an operator-cloned, established C workspace into the paired C0 arm."""
    config = read(root / ".unbug/config.json")
    state = read(root / ".unbug/state.json")
    contexts = list((root / ".unbug/checkpoints").glob("*/context.json"))
    if config["mode"] != "owner" or len(contexts) != 1:
        raise ValueError("C0 must fork the owner's first completed checkpoint, before maintenance")
    directory = contexts[0].parent
    if not read(directory / "result.json")["valid"] or state["checkpoint"] != directory.name:
        raise ValueError("The establishment checkpoint must have completed successfully")
    if state["inputs"] != fingerprint(root) or state["guard"] != guard_hash(root):
        raise ValueError("The establishment outputs changed before the C0 fork")
    if (root / ".unbug/frozen.json").exists():
        raise ValueError("Frozen seed already exists")
    write(root / ".unbug/frozen.json", state)
    write(root / ".unbug/fork.json", {"source_checkpoint": state["checkpoint"],
          "source_state_sha256": file_hash(root / ".unbug/state.json"), "created_at": now()})
    config["mode"] = "oneshot"
    if config.get("watcher_enabled"):
        watcher_module().stop(root)
    config["watcher_enabled"] = False
    write(root / ".unbug/config.json", config)
    (root / ".unbug/state.json").unlink()
    return {"mode": "oneshot", "source_checkpoint": state["checkpoint"], "usage_carried_forward": True}


def run_check(root, name, paths, label, command, timeout):
    directory = checkpoint(root, name)
    context = read(directory / "context.json")
    if (directory / "result.json").exists():
        raise ValueError("Checkpoint has already finished")
    if not paths or not set(paths) <= set(context["required_paths"]):
        raise ValueError("Check must name current required paths")
    if not command or timeout <= 0 or timeout > 1800:
        raise ValueError("Supply a command and timeout in 1..1800 seconds")
    identifier = uuid.uuid4().hex
    start = time.monotonic()
    before = fingerprint(root)
    output_dir = directory / "checks"
    output_dir.mkdir(exist_ok=True)
    error = None
    with (output_dir / f"{identifier}.stdout").open("w") as stdout, (output_dir / f"{identifier}.stderr").open("w") as stderr:
        process = subprocess.Popen(command, cwd=root, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            import signal
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait()
            error = "timeout"
    after = fingerprint(root)
    record = {"id": identifier, "checkpoint": name, "paths": paths, "label": label,
              "command": command, "created_at": now(), "seconds": time.monotonic() - start,
              "exit_code": code, "error": error, "inputs": before,
              "pass": code == 0 and error is None and before == after}
    write(output_dir / f"{identifier}.json", record)
    return record


def review(root, name):
    directory = checkpoint(root, name)
    context = read(directory / "context.json")
    proposal = read(directory / "proposal.json")
    errors = []
    if not isinstance(proposal, dict):
        return ["Proposal must be a JSON object"]
    claims = proposal.get("claims")
    if not isinstance(proposal.get("response"), str) or proposal["response"] not in RESPONSES or not isinstance(claims, list) or not all(
            isinstance(c, dict) and isinstance(c.get("path"), str) for c in claims):
        return ["Proposal needs a valid response and claims list"]
    if len(claims) != len(context["required_paths"]) or {c.get("path") for c in claims} != set(context["required_paths"]):
        errors.append("Exactly one claim is required for every current sales path")
    if not isinstance(proposal.get("rationale"), str) or not proposal["rationale"].strip():
        errors.append("Explain the response in rationale")
    if not isinstance(proposal.get("assumptions"), list) or not proposal["assumptions"] or not all(
            isinstance(item, str) and item.strip() for item in proposal["assumptions"]):
        errors.append("Record the assumptions behind the protection")
    if not isinstance(proposal.get("evidence", {}), dict):
        return errors + ["Evidence must map paths to lists of check identifiers"]
    current = fingerprint(root)
    for claim in claims:
        if claim.get("rule") != "never-oversell" or not isinstance(claim.get("status"), str) or claim["status"] not in STATUSES:
            errors.append("Invalid rule or claim status")
            continue
        if claim["status"] in {"protected", "withdrawn-safe-fallback"}:
            evidence = proposal.get("evidence", {}).get(claim.get("path"), [])
            if not isinstance(evidence, list):
                errors.append(f"{claim.get('path')}: evidence must be a list")
                continue
            valid = False
            for identifier in evidence:
                if not isinstance(identifier, str) or not re.fullmatch(r"[a-f0-9]{32}", identifier):
                    continue
                file = directory / "checks" / f"{identifier}.json"
                if file.exists():
                    check = read(file)
                    valid |= (check.get("pass") is True and check.get("checkpoint") == name
                              and claim["path"] in check.get("paths", []) and check.get("inputs") == current)
            if not valid:
                errors.append(f"{claim['path']}: no passing, current, locally executed check")
    if context["previous"] and context["guard_before"] != guard_hash(root) and proposal["response"] == "keep":
        errors.append("The guard changed; response cannot be keep")
    if context["previous"] is None and proposal["response"] != "keep":
        errors.append("The first checkpoint must use keep")
    if read(root / ".unbug/config.json").get("watcher_enabled") and any(
            c.get("status") in {"protected", "withdrawn-safe-fallback"} for c in claims):
        errors.extend(watcher_module().ready_errors(root))
    return errors


def model_usage(log):
    """Read the provider's final result; missing accounting stays unknown, never zero."""
    result = None
    if log.exists():
        for line in log.read_text(errors="replace").splitlines():
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if isinstance(event, dict) and event.get("type") == "result":
                result = event
    if result is None:
        return {"cost_usd": None, "usage": None, "model_succeeded": False}
    cost = result.get("total_cost_usd")
    if isinstance(cost, bool) or not isinstance(cost, (int, float)) or not math.isfinite(cost) or cost < 0:
        cost = None
    return {"cost_usd": cost, "usage": result.get("usage"),
            "model_succeeded": result.get("is_error") is False and result.get("subtype") == "success"}


def finish(root, name, log, execution_ok=True):
    directory = checkpoint(root, name)
    if (directory / "result.json").exists():
        raise ValueError("Checkpoint already finalized")
    context = read(directory / "context.json")
    usage = model_usage(log)
    errors = []
    if not execution_ok or not usage["model_succeeded"]:
        errors.append("Model execution did not finish successfully")
    if usage["cost_usd"] is None:
        errors.append("Model cost is unknown")
    elif usage["cost_usd"] > context["remaining_usd"]:
        errors.append("Model exceeded the remaining attempt budget")
    try:
        errors.extend(review(root, name))
    except (OSError, ValueError, TypeError, KeyError) as error:
        errors.append(f"Invalid or missing proposal: {error}")
    response = "repair" if context["previous"] and context["guard_before"] != guard_hash(root) else "keep"
    if errors:
        fallback(root, context["required_paths"], response)
    else:
        proposal = read(directory / "proposal.json")
        claims = {"response": proposal["response"], "claims": proposal["claims"]}
        write(root / "claims.json", claims)
        state = {"checkpoint": name, "updated_at": now(), "claims": claims,
                 "rationale": proposal["rationale"], "assumptions": proposal["assumptions"],
                 "lessons": proposal.get("lessons", []), "inputs": fingerprint(root), "guard": guard_hash(root)}
        if context["mode"] == "owner":
            write(root / ".unbug/state.json", state)
            alert = root / ".unbug/watcher/escalation.json"
            if (read(root / ".unbug/config.json").get("watcher_enabled") and alert.exists()
                    and not watcher_module().ready_errors(root)):
                record = read(alert)
                record["resolved_by_checkpoint"] = name
                write(alert, record)
        elif not (root / ".unbug/frozen.json").exists():
            write(root / ".unbug/frozen.json", state)
    usage_record = {"checkpoint": name, "created_at": now(), **usage, "execution_ok": execution_ok}
    with (root / ".unbug/usage.jsonl").open("a") as handle:
        handle.write(json.dumps(usage_record, allow_nan=False) + "\n")
    result = {"checkpoint": name, "valid": not errors, "errors": errors, "usage": usage}
    write(directory / "result.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/app"))
    sub = parser.add_subparsers(dest="action", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--id", required=True)
    p.add_argument("--instruction", type=Path, required=True)
    p.add_argument("--mode", choices=("owner", "oneshot"), required=True)
    p.add_argument("--model", required=True)
    p.add_argument("--budget", type=float, required=True)
    p.add_argument("--watcher", action="store_true")
    p.add_argument("--watcher-cpu-budget-seconds", type=float, default=300)
    p.add_argument("--watcher-wall-budget-seconds", type=float, default=86400)
    p = sub.add_parser("check")
    p.add_argument("--id", required=True)
    p.add_argument("--paths", required=True)
    p.add_argument("--label", required=True)
    p.add_argument("--timeout", type=int, default=180)
    p.add_argument("command", nargs=argparse.REMAINDER)
    for action in ("review", "finish"):
        p = sub.add_parser(action)
        p.add_argument("--id", required=True)
        if action == "finish":
            p.add_argument("--usage-log", type=Path, required=True)
            p.add_argument("--failed", action="store_true")
    p = sub.add_parser("fork-oneshot")
    p.add_argument("--confirm-cloned-workspace", action="store_true", required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    with lock(root):
        if args.action == "prepare":
            result = prepare(root, args.id, args.instruction.read_text(), args.mode, args.model, args.budget,
                             args.watcher, args.watcher_cpu_budget_seconds, args.watcher_wall_budget_seconds)
        elif args.action == "check":
            command = args.command[1:] if args.command[:1] == ["--"] else args.command
            result = run_check(root, args.id, args.paths.split(","), args.label, command, args.timeout)
        elif args.action == "review":
            errors = review(root, args.id)
            result = {"valid": not errors, "errors": errors}
        elif args.action == "fork-oneshot":
            result = fork_oneshot(root)
        else:
            result = finish(root, args.id, args.usage_log, not args.failed)
    print(json.dumps(result, allow_nan=False))
    if result.get("pass") is False or result.get("valid") is False:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
