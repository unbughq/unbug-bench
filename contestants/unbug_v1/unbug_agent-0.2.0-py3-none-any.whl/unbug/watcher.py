"""Detached, model-free supervision of an agent-authored live outcome probe.

The probe owns business semantics. This runner owns liveness, positive controls,
timeouts, escalation, and accounting; it never treats missing data as success.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime
import fcntl
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time
import uuid

CHILDREN = {}  # Reap daemons when the launcher is still alive (e.g. local tests).

try:
    from . import runtime as rt
except ImportError:  # The adapter uploads two standalone scripts, not an installed package.
    source = Path(__file__).with_name("runtime.py")
    if not source.exists():
        source = source.with_name("unbug-runtime.py")
    spec = importlib.util.spec_from_file_location("unbug_runtime", source)
    rt = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rt)


def directory(root):
    path = root / ".unbug/watcher"
    path.mkdir(parents=True, exist_ok=True)
    return path


def append(path, value):
    with path.open("a") as handle:
        handle.write(json.dumps(value, allow_nan=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


@contextmanager
def file_lock(path, blocking=True):
    with path.open("a+") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        yield


def running(root):
    path = directory(root)
    try:
        with file_lock(path / "daemon.lock", blocking=False):
            return None
    except BlockingIOError:
        return rt.read(path / "pid.json")


def start(root):
    """Popen(start_new_session=True) is setsid, with all terminal streams detached."""
    path = directory(root)
    with file_lock(path / "start.lock"):
        existing = running(root)
        if existing:
            return existing
        previous = CHILDREN.pop(root, None)
        if previous:
            previous.wait(timeout=5)
        with (path / "process.log").open("a") as output:
            process = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "--root", str(root), "run"],
                                       cwd=root, stdin=subprocess.DEVNULL, stdout=output, stderr=output,
                                       start_new_session=True, close_fds=True)
        CHILDREN[root] = process
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            if process.poll() is not None:
                if process.returncode == 0 and (path / "pid.json").exists():
                    record = rt.read(path / "pid.json")
                    if record["pid"] == process.pid:
                        return record  # E.g. exhausted budget; readiness still fails closed.
                raise RuntimeError(f"Watcher exited during startup ({process.returncode}); inspect {path / 'process.log'}")
            try:
                record = running(root)
                if record and record["pid"] == process.pid:
                    return record
            except FileNotFoundError:
                pass
            time.sleep(.02)
        raise RuntimeError("Watcher did not record its PID within five seconds")


def stop(root):
    # A copied pid.json is not proof of a live process in a cloned C0 workspace.
    record = running(root)
    if record:
        os.kill(record["pid"], signal.SIGTERM)
        deadline = time.monotonic() + 5
        while running(root) and time.monotonic() < deadline:
            time.sleep(.02)
        if running(root):
            raise RuntimeError("Watcher did not stop; refusing to freeze a live C0 arm")
    child = CHILDREN.pop(root, None)
    if child:
        child.wait(timeout=5)
    return {"running": False}


def totals(root):
    records = directory(root) / "usage.jsonl"
    if not records.exists():
        return {"cpu_seconds": 0.0, "wall_seconds": 0.0}
    last = json.loads(records.read_text().splitlines()[-1])
    return last["compute_total"]


class Meter:
    def __init__(self, root):
        self.root = root
        self.wall = time.monotonic()
        self.cpu = 0.0

    def record(self, kind):
        own = resource.getrusage(resource.RUSAGE_SELF)
        children = resource.getrusage(resource.RUSAGE_CHILDREN)
        cpu = own.ru_utime + own.ru_stime + children.ru_utime + children.ru_stime
        wall = time.monotonic()
        delta = {"cpu_seconds": max(0, cpu - self.cpu), "wall_seconds": wall - self.wall}
        previous = totals(self.root)
        total = {k: previous[k] + delta[k] for k in delta}
        record = {"created_at": rt.now(), "kind": kind, "pid": os.getpid(),
                  "model": None, "model_calls": 0, "cost_usd": 0.0,
                  "usage": {"input_tokens": 0, "output_tokens": 0},
                  "compute": delta, "compute_total": total,
                  "peak_rss_bytes": max(own.ru_maxrss, children.ru_maxrss) * (1 if sys.platform == "darwin" else 1024),
                  "compute_cost_usd": None, "compute_pricing": "operator-priced; raw units count against the attempt"}
        append(directory(self.root) / "usage.jsonl", record)
        self.cpu, self.wall = cpu, wall
        return total


def configuration(root):
    config = rt.read(root / ".unbug/watch.json")
    command = config["command"]
    if not isinstance(command, list) or not command or not all(isinstance(s, str) and s for s in command):
        raise ValueError("watch.json command must be a nonempty argv list")
    paths = config["paths"]
    if not isinstance(paths, list) or not paths or not all(isinstance(p, str) for p in paths) or len(paths) != len(set(paths)):
        raise ValueError("watch.json must name each covered path once")
    interval, timeout = config.get("interval_seconds", 60), config.get("timeout_seconds", 30)
    for value, upper in ((interval, 300), (timeout, 60)):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not .05 <= value <= upper:
            raise ValueError("Invalid watcher interval or timeout")
    return {**config, "interval_seconds": interval, "timeout_seconds": timeout}


def interpret(report):
    """Reject vacuous success; the agent must supply real, independently checked controls."""
    reasons = []
    if not isinstance(report, dict):
        raise ValueError("Probe output must be a JSON object")
    for key in ("violations", "confirmation_failures"):
        if not isinstance(report.get(key), list):
            raise ValueError(f"Probe must report {key}")
        if report[key]:
            reasons.append(key)
    checks = report.get("enforcement_checks")
    if not isinstance(checks, list) or not checks:
        raise ValueError("Probe must inspect installed enforcement")
    if any(not isinstance(c, dict) or not c.get("id") or c.get("ok") is not True for c in checks):
        reasons.append("enforcement_degraded")
    count = report.get("outcomes_checked")
    controls = report.get("visibility_controls")
    visible = (isinstance(count, int) and not isinstance(count, bool) and count > 0
               and isinstance(controls, list) and bool(controls)
               and all(isinstance(c, dict) and c.get("id") and c.get("source")
                       and c.get("expected") not in (None, {}, [], "", 0, False)
                       and "observed" in c and c["expected"] == c["observed"] for c in controls))
    if not visible:
        reasons.append("observability_degraded")
    return reasons


def invalid_constant(value):
    raise ValueError(f"Non-finite JSON value from probe: {value}")


def publish(root, status):
    path = directory(root)
    # Serialize status and claims with checkpoint finalization, but never hold
    # the checkpoint lock while a potentially slow live probe executes.
    while True:
        try:
            with rt.lock(root):
                old = rt.read(path / "status.json") if (path / "status.json").exists() else {}
                if (old.get("state"), old.get("reasons")) != (status["state"], status["reasons"]):
                    append(path / "events.jsonl", {"created_at": rt.now(), "state": status["state"],
                                                  "reasons": status["reasons"], "sample": status["sample"]})
                if status["state"] != "healthy":
                    rt.write(path / "escalation.json", {"created_at": rt.now(), "sample": status["sample"],
                                                       "reasons": status["reasons"], "resolved_by_checkpoint": None})
                pending = rt.read(path / "escalation.json") if (path / "escalation.json").exists() else None
                if pending and pending["resolved_by_checkpoint"] is None:
                    claims_path = root / "claims.json"
                    if claims_path.exists():
                        claims = rt.read(claims_path)
                        claims["response"] = "escalate"
                        for claim in claims["claims"]:
                            if claim["status"] in {"protected", "withdrawn-safe-fallback"}:
                                claim["status"] = "escalated"
                        rt.write(claims_path, claims)
                # Publish the status last: an unlocked reader that sees a failed
                # sample must already see the corresponding claims downgrade.
                rt.write(path / "status.json", status)
                return
        except BlockingIOError:
            time.sleep(.05)


def sample(root, meter):
    path = directory(root)
    with file_lock(path / "sample.lock"):
        status = {"sample": uuid.uuid4().hex, "created_at": rt.now(), "state": "unknown", "reasons": [], "report": None}
        config = None
        try:
            limits = rt.read(root / ".unbug/config.json")
            used = meter.record("before_sample")  # Charge idle/startup time before authorizing more work.
            if used["cpu_seconds"] >= limits["watcher_cpu_budget_seconds"] or used["wall_seconds"] >= limits["watcher_wall_budget_seconds"]:
                raise ValueError("watcher_compute_budget_exhausted")
            config = configuration(root)
            before = rt.fingerprint(root)
            status["inputs"] = before
            current = rt.read(root / ".unbug/current.json")
            context = rt.read(rt.checkpoint(root, current["checkpoint"]) / "context.json")
            if set(config["paths"]) != set(context["required_paths"]):
                raise ValueError("Probe does not cover the current required paths")
            with (path / "probe.stdout").open("w") as stdout, (path / "probe.stderr").open("w") as stderr:
                process = subprocess.Popen(config["command"], cwd=root, stdin=subprocess.DEVNULL,
                                           stdout=stdout, stderr=stderr, start_new_session=True, close_fds=True)
                try:
                    code = process.wait(timeout=min(config["timeout_seconds"],
                                                    limits["watcher_wall_budget_seconds"] - used["wall_seconds"]))
                finally:
                    # Also reap descendants that outlived the probe leader.
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait()
            if code != 0:
                raise ValueError(f"Probe exited {code}; inspect watcher/probe.stderr")
            if (path / "probe.stdout").stat().st_size > 262144:
                raise ValueError("Probe output exceeds 256 KiB")
            report = json.loads((path / "probe.stdout").read_text(), parse_constant=invalid_constant)
            status["report"] = report
            status["reasons"] = interpret(report)
            if before != rt.fingerprint(root):
                status["reasons"].append("inputs_changed_during_probe")
            status["state"] = "degraded" if status["reasons"] else "healthy"
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired) as error:
            status["reasons"] = [str(error)]
        finally:
            status["compute_total"] = meter.record("sample")
        if config:
            status["interval_seconds"] = config["interval_seconds"]
        limits = rt.read(root / ".unbug/config.json")
        if any(status["compute_total"][unit] >= limits[limit] for unit, limit in
               (("cpu_seconds", "watcher_cpu_budget_seconds"), ("wall_seconds", "watcher_wall_budget_seconds"))):
            status["state"], status["reasons"] = "unknown", ["watcher_compute_budget_exhausted"]
        status["completed_at"] = rt.now()
        append(path / "samples.jsonl", status)
        publish(root, status)
        return status


def ready_errors(root):
    try:
        if not running(root):
            return ["Between-changes watcher is not running"]
        status = rt.read(directory(root) / "status.json")
        config = configuration(root)
        age = time.time() - datetime.fromisoformat(status["completed_at"]).timestamp()
        if status["state"] != "healthy" or not 0 <= age <= config["interval_seconds"] + config["timeout_seconds"] + 5:
            return ["Between-changes watcher is degraded or stale; inspect .unbug/watcher/status.json"]
        if status.get("inputs") != rt.fingerprint(root):
            return ["Watcher has not checked the final source, guard, and probe configuration"]
        current = rt.read(root / ".unbug/current.json")["checkpoint"]
        if set(config["paths"]) != set(rt.read(rt.checkpoint(root, current) / "context.json")["required_paths"]):
            return ["Watcher does not cover all current required paths"]
    except (OSError, ValueError, KeyError, TypeError) as error:
        return [f"Between-changes watcher is not ready: {error}"]
    return []


def run(root):
    path = directory(root)
    with file_lock(path / "daemon.lock", blocking=False):
        meter = Meter(root)
        def terminate(signum, frame):
            raise SystemExit(0)
        signal.signal(signal.SIGTERM, terminate)
        signal.signal(signal.SIGHUP, signal.SIG_IGN)
        rt.write(path / "pid.json", {"pid": os.getpid(), "session_id": os.getsid(0), "started_at": rt.now()})
        try:
            while rt.read(root / ".unbug/config.json").get("watcher_enabled"):
                status = sample(root, meter)
                if "watcher_compute_budget_exhausted" in status["reasons"]:
                    break
                limit = rt.read(root / ".unbug/config.json")["watcher_wall_budget_seconds"]
                time.sleep(max(0, min(status.get("interval_seconds", 5), limit - totals(root)["wall_seconds"])))
        except Exception as error:
            publish(root, {"sample": uuid.uuid4().hex, "created_at": rt.now(), "completed_at": rt.now(),
                           "state": "unknown", "reasons": [f"Watcher failed: {error}"], "report": None})
            raise
        finally:
            with file_lock(path / "sample.lock"):
                meter.record("shutdown")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/app"))
    parser.add_argument("action", choices=("start", "stop", "check", "run"))
    args = parser.parse_args()
    root = args.root.resolve()
    if args.action == "run":
        run(root)
        return
    if args.action == "start":
        result = start(root)
    elif args.action == "stop":
        result = stop(root)
    else:
        result = sample(root, Meter(root))
    print(json.dumps(result, allow_nan=False))
    if result.get("state") not in (None, "healthy"):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
