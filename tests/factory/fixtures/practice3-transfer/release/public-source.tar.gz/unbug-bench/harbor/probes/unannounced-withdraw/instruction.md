Infrastructure probe.
