#!/usr/bin/env python3
"""Offline launch guard checks: python3 tests/bench/test-launch-guards.py.
Use --restore-only for the archive transfer and recovery checks.
Copies only launch scripts into a temp bench. Never invokes real boat or paid services.
"""

import sys
from pathlib import Path as _Path

_BENCH_ROOT = _Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_BENCH_ROOT / "bin"))

import json
import os
import pathlib
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile
import time

ROOT = _BENCH_ROOT
sys.path.insert(0, str(ROOT / 'factory'))
from launch_manifest import worker_files
# Hang guard only, not a deadline under test: phases are event-driven, so a
# loaded host may legitimately need minutes for one synthetic launch.
HANG_GUARD_SECONDS = 900
FAKE = r'''#!/usr/bin/env python3
import json, os, pathlib, shlex, signal, subprocess, sys, time
root = pathlib.Path(os.environ["FAKE_STATE"])
mode = os.environ.get("FAKE_MODE", "finish")
EPOCH = 1000000000
def advance(seconds):
    event = pathlib.Path(os.environ['FAKE_COMMAND_CLOCK'])
    with (root / 'clock-events').open('a') as f:
        f.write(json.dumps({'event': str(event), 'seconds': seconds, 'args': args}) + '\n')
    pending = event.with_suffix('.tmp')
    pending.write_text(str(seconds)); pending.replace(event)
    while not event.with_suffix('.observed').exists(): time.sleep(.01)
def hang():
    advance(float(os.environ.get('BOAT_COMMAND_TIMEOUT_SECONDS', '120')) + 1)
    signal.pause()  # The real process owner must kill this command.
args = sys.argv[1:]
with (root / "calls").open("a") as f: f.write(json.dumps(args) + "\n")
cmd = args[0]
def vmdir(id): return root / id
if cmd == "billing":
    if mode == "bad-billing": print('{}'); sys.exit(0)
    balance = int(os.environ.get("FAKE_BALANCE", "1000000"))
    balance -= len(list(root.glob("vm-*/deleted"))) * 100
    print(json.dumps({"limits": {"creditBalanceSeconds": balance}}))
elif cmd == "new":
    id = "vm-" + str(len(list(root.glob("vm-*"))) + 1)
    vmdir(id).mkdir()
    print(json.dumps({"event": "creating"}))
    print(json.dumps({"event": "created", "id": id}), flush=True)
    if mode == "new-fail": sys.exit(1)
elif cmd == "exec":
    if mode == 'stall':
        # More than a pipe buffer: readiness must not wait with undrained output.
        sys.stderr.write('synthetic setup diagnostics\n' * 16384); sys.stderr.flush()
    if os.environ.get("EXAM_CLAUDE_SECRET") == "claude-token-2":
        assert (vmdir(args[1]) / "shm-secrets/claude-token").read_text() == "fake-claude-token-2\n"
    vm = vmdir(args[1]); (vm / "sealed").mkdir(exist_ok=True); (vm / "exam-out").mkdir(exist_ok=True)
    if "factory/run.py" in args[-1]:
        import hashlib
        statement = vm / "statements/case-old.statement.age"
        assert hashlib.sha256(statement.read_bytes()).hexdigest() == os.environ['FAKE_STATEMENT_SHA']
        board = vm / "statements/selection-board.json"
        if "--resume" not in args[-1]:
            assert board.is_file(), "new factory launches need the advisory selection board"
        if board.exists():
            assert json.loads(board.read_text()) == {
                'version': 1, 'scope': 'selection_only', 'complete': True,
                'registry_revision': 1, 'statements': {'case-old': os.environ['FAKE_STATEMENT_SHA']}}
            assert not (vm / "statements/admission.json").exists(), 'selection history grants no reservation'
        assert (vm / "shm-secrets/statements-key").read_text() == "fake-statements-key\n"
        assert "export OPENCODE_DISABLE_AUTOUPDATE=1" in args[-1]
        assert (vm / "opencode-version").read_text() == "1.19.0"
        if "'--continue-g11-review'" in args[-1]:
            assert "--resume 'case-synthetic'" in args[-1]
            assert (vm / "work/case-synthetic/g11-audit/case/promise.md").read_text() == "synthetic case"
            assert (vm / "work/case-synthetic/g11-audit/notes.txt").read_text() == "saved review notes"
            assert json.loads((vm / "sealed/case-synthetic.continuation-budget.json").read_text())["calls"] == 49
    (vm / "work").mkdir(exist_ok=True); (vm / "jobs").mkdir(exist_ok=True)
    if "bin/run-exam" in args[-1]:
        (vm / "exam").touch()
        (vm / "exam-private/trial/jobs").mkdir(parents=True)
    (vm / ".boat-launch-start").touch()
    if mode == 'startup-crash':
        (vm / 'sealed/runner-status.json').write_text(json.dumps(dict(schema=1, attempt=3,
            phase='startup', reason='startup_failed', exit_status=1, observed_at=time.time())))
    if mode == 'containment-unavailable':
        (vm / 'sealed/runner-status.json').write_text(json.dumps(dict(schema=1, attempt=0,
            phase='startup', reason='containment_unavailable', exit_status=78, observed_at=time.time())))
    for dest in ("sealed", "exam-out"):
        (vm / dest / "result.scorecard.txt").write_text("fake scorecard\n")
        (vm / dest / "result.jobs.tar.gz.age").write_text("fake sealed bytes")
        (vm / dest / "result.statement.age").write_text("fake statement ciphertext")
    (vm / "exam-stdout").write_text("fake exam scorecard\n")
    if mode in ("finish", "collect-fail", "delete-fail", "reuse-review") or (mode == "mixed" and args[1] == "vm-2"):
        (vm / "sealed/DONE").touch(); (vm / "exam-out/DONE").touch()
    if mode.startswith("autoretry"):
        import hashlib
        case = "case-synthetic"
        folder = vm / "sealed"
        count = vm / "exec-count"
        attempt = int(count.read_text()) + 1 if count.exists() else 1
        count.write_text(str(attempt))
        # Each completed retry publishes a new checkpoint generation and retains
        # cumulative work. Repeating identical old cards is correctly not retried.
        payload = ("synthetic ciphertext generation " + str(attempt)).encode()
        (folder / (case + ".checkpoint.tar.gz.age")).write_bytes(payload)
        card = {"case":case, "seed":42, "status":"stopped", "terminal_stop":"stalled",
                "sha256":hashlib.sha256(payload).hexdigest(),
                "continuation_budget":{"cost":0.25 * attempt,"calls":2 * attempt,"events":[],"terminal_stop":"stalled"}}
        if mode == "autoretry-gate": card["failed_gate"] = "G8"
        if mode == "autoretry-cap": card["terminal_stop"] = "call_limit"
        if mode == "autoretry-corrupt": card["sha256"] = "0" * 64
        if mode == "autoretry-nohash": card.pop("sha256")
        (folder / (case + ".scorecard.json")).write_text(json.dumps(card))
        (folder / "DONE").write_text(case)
        if "--resume case-synthetic" in args[-1]:
            assert "--resume-bench-sha " + "a"*64 in args[-1]
            assert "--seed 42" in args[-1]
            assert "'--max-total-calls' '700'" in args[-1]
            assert "'--max-cost' '2'" in args[-1]
            assert "test -f ~/sealed/case-synthetic.continuation-budget.json" in args[-1]
            assert "factory-restart.lock" in args[-1]
            if mode == "autoretry-uncertain":
                (folder / (case + ".checkpoint.tar.gz.age")).write_bytes(b"new uncertain checkpoint")
                card["sha256"] = hashlib.sha256(b"new uncertain checkpoint").hexdigest()
                (folder / (case + ".scorecard.json")).write_text(json.dumps(card))
                sys.exit(1)  # remote mutation succeeded; its transport acknowledgement was lost
    # Watchdog observations use a fixed epoch; slow scheduling cannot age work.
    for path in [vm, *vm.rglob('*')]: os.utime(path, (EPOCH, EPOCH))
elif cmd == "ssh":
    vm = vmdir(args[1]); command = args[2]
    if "cat > ~/factory.tgz" in command:
        # Exercise the real streamed bytes and checksum; fake only the transport.
        sys.exit(subprocess.run(["/bin/sh", "-c", command],
            input=sys.stdin.buffer.read(), env={**os.environ, "HOME":str(vm)}).returncode)
    elif "mkdir /home/user/.statements-stage-" in command and "tar -xzf -" in command:
        # Run the real snapshot extraction in this synthetic VM; the following
        # Python swap still checks every transferred digest before installation.
        status = subprocess.run(["/bin/sh", "-c", command.replace("/home/user/", str(vm) + "/")],
            input=sys.stdin.buffer.read(), env={**os.environ, "HOME": str(vm)}).returncode
        if mode == 'setup-timeout': hang()
        sys.exit(status)
    elif "print(run.bench_manifest())" in command:
        print("a" * 64)
    elif 'docker image inspect unbug-bench-medusa:latest' in command:
        assert not (vm / 'secrets-ok').exists(), 'image preparation must precede credentials'
        assert 'pull postgres redis && docker compose -f projects/medusa/compose.yaml build medusa' in command
        if mode == 'image-fail': sys.exit(1)
        (vm / 'medusa-image-prepared').touch()
    elif 'factory/worker_release.py' in command:
        assert (vm / 'medusa-image-prepared').exists(), 'image fallback must precede qualification'
        assert not (vm / 'secrets-ok').exists(), 'qualification must precede credentials'
        if mode == 'qualification-fail': sys.exit(1)
        if mode == 'second-qualification-fail' and args[1] == 'vm-2':
            (root / 'second-failed').touch(); sys.exit(1)
        print(json.dumps({'schema':1,'verified_drivers':['opencode','codex']}))
    elif command == 'if test -d ~/sealed/.factory-restart.lock; then echo locked; else echo unlocked; fi':
        print('unlocked')
    elif command == "cat ~/sealed/DONE":
        print((vm / "sealed/DONE").read_text())
    elif 'factory/case_permissions.py --extract-to' in command:
        assert float(os.environ.get('BOAT_COMMAND_TIMEOUT_SECONDS','120')) == float(os.environ.get('FAKE_EXPECT_RESTORE_TIMEOUT','1200')), 'restore inherited ordinary SSH timeout'
        if os.environ.get('FAKE_RESTORE_ELAPSED'): advance(float(os.environ['FAKE_RESTORE_ELAPSED']))
        key = sys.stdin.buffer.read()
        assert key != pathlib.Path(os.environ['FAKE_IDENTITY']).read_bytes(), 'founder identity sent to worker'
        command = command.replace('/dev/shm/casekey', str(vm / 'casekey'))
        command = command.replace('~/factory/case_permissions.py', os.environ['FAKE_PERMISSION_HELPER'])
        sys.exit(subprocess.run(['/bin/sh', '-c', command], input=key,
            env={**os.environ, 'HOME':str(vm)}, umask=0o077).returncode)
    elif command == 'umask 077; cat > ~/restore.age':
        (vm / 'restore.age').write_bytes(sys.stdin.buffer.read())
    elif "cat > ~/sealed/case-synthetic.continuation-budget.json" in command:
        folder = vm / "sealed"; folder.mkdir(exist_ok=True)
        (folder / "case-synthetic.continuation-budget.json").write_bytes(sys.stdin.buffer.read())
    elif command == "test -d ~/work/case-synthetic/g11-audit/case":
        sys.exit(0 if (vm / "work/case-synthetic/g11-audit/case").is_dir() else 1)
    elif "cat > /dev/shm/exam-key" in command:
        assert sys.stdin.read() == pathlib.Path(os.environ["FAKE_IDENTITY"]).read_text()
    elif "base64 -d | tar" in command:
        import base64, io, tarfile, re
        shm = vm / "shm-secrets"; shm.mkdir(exist_ok=True)
        tarfile.open(fileobj=io.BytesIO(base64.b64decode(sys.stdin.read()))).extractall(shm, filter="data")
        names = re.search(r"for n in (.*?); do", command).group(1).split()
        if not all((json.loads((shm / n).read_text())['tokens']['access_token'].endswith('.synthetic')
                    if n == 'codex-auth.json' else (shm / n).read_text() == "fake-" + n + "\n") for n in names): sys.exit(1)
        (vm / "secrets-ok").touch()
    elif command == "cp /dev/shm/secrets/claude-token-2 /dev/shm/secrets/claude-token":
        (vm / "shm-secrets/claude-token").write_text((vm / "shm-secrets/claude-token-2").read_text())
    elif "opencode" in command and "--version" in command:
        assert "/usr/local/bin/opencode" in command, "preflight must inspect the runner's absolute CLI"
        tools = vm / "tools"; tools.mkdir()
        prefix = vm / "usr/local"; (prefix / "bin").mkdir(parents=True)
        (vm / "opencode-version").write_text(os.environ.get("FAKE_OPENCODE_VERSION", "1.19.0"))
        cli = prefix / "bin/opencode"
        cli.write_text('#!/usr/bin/env python3\nimport os,pathlib,sys\nassert os.environ.get("OPENCODE_DISABLE_AUTOUPDATE")=="1"\nassert sys.argv[1:]==["--version"]\nprint((pathlib.Path(os.environ["FAKE_VM"])/"opencode-version").read_text())\n')
        cli.chmod(0o755)
        (vm / "codex-version").write_text(os.environ.get("FAKE_CODEX_VERSION", "0.162.1"))
        codex = prefix / "bin/codex"
        codex.write_text('#!/usr/bin/env python3\nimport os,pathlib\nprint("codex-cli " + (pathlib.Path(os.environ["FAKE_VM"])/"codex-version").read_text())\n')
        codex.chmod(0o755)
        # Poison PATH: only the absolute binary above is the version used by the runner.
        (tools / "opencode").write_text("#!/bin/sh\nexit 98\n"); (tools / "opencode").chmod(0o755)
        (tools / "sudo").write_text('#!/bin/sh\nexec "$@"\n'); (tools / "sudo").chmod(0o755)
        npm = tools / "npm"
        npm.write_text('#!/usr/bin/env python3\nimport os,pathlib,sys\np=pathlib.Path(os.environ["FAKE_VM"])\nassert os.environ.get("OPENCODE_DISABLE_AUTOUPDATE")=="1"\nassert "opencode-ai@1.19.0" in sys.argv or "@openai/codex@0.162.1" in sys.argv\nif "@openai/codex@0.162.1" in sys.argv:\n (p/"codex-installed").touch()\n if os.environ["FAKE_MODE"]=="codex-pin-install-fail": sys.exit(1)\n if os.environ["FAKE_MODE"]!="codex-pin-wrong-version": (p/"codex-version").write_text("0.162.1")\n sys.exit(0)\nassert sys.argv[sys.argv.index("--prefix")+1]==str(p/"usr/local")\n(p/"opencode-installed").touch()\nif os.environ["FAKE_MODE"]=="pin-install-fail": sys.exit(1)\nif os.environ["FAKE_MODE"]!="pin-wrong-version": (p/"opencode-version").write_text("1.19.0")\n')
        npm.chmod(0o755)
        env = dict(os.environ, FAKE_VM=str(vm), PATH=str(tools)+os.pathsep+os.environ["PATH"])
        sys.exit(subprocess.run(["/bin/sh", "-c", command.replace("/usr/local", str(prefix))], env=env).returncode)
    elif command.startswith("python3 -c ") and "snapshot transfer digest mismatch" in command:
        # Statement installation precedes the runner; it is not a watchdog poll.
        sys.exit(subprocess.run(["/bin/sh", "-c", command.replace("/home/user", str(vm))],
                                env=dict(os.environ, HOME=str(vm))).returncode)
    elif command.startswith(("python3 -c ", "OPENCODE_DISABLE_AUTOUPDATE=1 python3 -c ")):
        watchdog = '.boat-launch-start' in command
        if watchdog:
            (vm / "polled").touch()
            if os.environ.get('FAKE_SIGNAL') and not (root / 'signal-sent').exists():
                (root / 'signal-sent').touch()
                os.kill(int((root / 'launcher.pid').read_text()), int(os.environ['FAKE_SIGNAL']))
        if mode == 'second-qualification-fail' and args[1] == 'vm-1' and (root / 'second-failed').exists():
            (vm / 'sealed/DONE').touch()
        if mode == "collect-fail" and "pathlib.Path.home()" in command and "sealed" in command: sys.exit(1)
        if mode == "unreachable": sys.exit(1)
        if mode == "hang": hang()
        command = command.replace("/home/user", str(vm))
        now = EPOCH + (10 if mode in ('stale', 'mixed') else 0)
        if mode == "progress" and watchdog:
            count = vm / "poll-count"
            n = int(count.read_text()) + 1 if count.exists() else 1
            count.write_text(str(n))
            # Match run-exam's real private job directory, which is absent from ~/jobs.
            progress = vm / ('exam-private/trial/jobs/progress' if (vm / 'exam').exists()
                             else 'sealed/case.continuation-budget.json')
            now = EPOCH + 10 * n
            progress.touch(); os.utime(progress, (now, now))
            # Directory creation timestamps must not mask a missing file scan.
            os.utime(progress.parent, (EPOCH, EPOCH))
            if n >= 5:
                (vm / "sealed/DONE").touch(); (vm / "exam-out/DONE").touch()
        if watchdog:
            python, flag, source = shlex.split(command)
            assert (python, flag) == ('python3', '-c')
            command = shlex.join([python, flag, f'import time; time.time = lambda: {now}\n' + source])
        env = dict(os.environ, HOME=str(vm))
        sys.exit(subprocess.run(["/bin/sh", "-c", command], env=env).returncode)
    elif 'test ! -f ~/sealed/runner-status.json' in command:
        status = vm / 'sealed/runner-status.json'
        if status.exists(): print(status.read_text())
    elif "ls *." in command:
        folder = "exam-out" if "exam-out" in command else "sealed"
        if not (vm / folder).exists():  # both collectors: no output folder = nothing to collect
            if folder == "exam-out": print("NOTHING")
            sys.exit(0)
        if mode.startswith("autoretry"):
            print("case-synthetic.scorecard.json\ncase-synthetic.checkpoint.tar.gz.age")
        else:
            print("result.scorecard.txt\nresult.jobs.tar.gz.age" + ("\nresult.statement.age" if folder == "sealed" else ""))
    elif command.startswith("sha256sum ") and mode.startswith("autoretry"):
        import hashlib
        print(hashlib.sha256((vm / "sealed" / command.rsplit("/",1)[-1]).read_bytes()).hexdigest())
    elif command == "cat ~/exam-stdout":
        if not (vm / "exam-stdout").exists(): sys.exit(1)
        print((vm / "exam-stdout").read_text(), end="")
    elif command.startswith('if [ ! -f ~/sealed/DONE ]'):
        sys.exit(0)  # Setup failure is not a failed collector pause/transport.
    elif mode == "setup-fail": sys.exit(1)
elif cmd == "scp":
    if args[1].endswith(".statement.age") and not args[1].startswith("vm-"):
        import shutil
        id = args[2].split(":")[0]
        dest = vmdir(id) / "statements"
        dest.mkdir(exist_ok=True)
        shutil.copyfile(args[1], dest / pathlib.Path(args[1]).name)
    if args[1].startswith("vm-"):
        if mode == "collect-fail": sys.exit(1)
        if mode.startswith("autoretry"):
            import shutil
            source = vmdir(args[1].split(":")[0]) / "sealed" / args[1].rsplit("/", 1)[-1]
            shutil.copyfile(source, args[2])
        else: pathlib.Path(args[2]).write_text("fake sealed result\n")
elif cmd == "delete":
    if mode == "delete-fail": sys.exit(1)
    (vmdir(args[1]) / "deleted").touch()
    print(json.dumps({'operation': {'id': 'op-' + args[1], 'targetId': args[1],
          'kind': 'sandbox', 'status': 'pending', 'stage': 'queued', 'completedAt': None,
          'privateDiagnostic': 'must not persist'}}))
elif cmd == "deletion":
    assert args[1] == 'status' and args[3] == '--json'
    if mode == 'deletion-unavailable': sys.exit(1)
    operation = dict(id=args[2], targetId=args[2].removeprefix('op-'), kind='sandbox',
                     status='completed', stage='completed', completedAt='2026-10-22T22:00:00Z',
                     privateDiagnostic='must not persist')
    if mode == 'deletion-wrong-worker': operation['targetId'] = 'other-worker'
    if mode == 'deletion-wrong-operation': operation['id'] = 'other-operation'
    if mode == 'deletion-wrong-kind': operation['kind'] = 'volume'
    if mode == 'deletion-incomplete': operation.update(status='processing', stage='deleting', completedAt=None)
    if mode == 'deletion-wrong-stage': operation['stage'] = 'deleting'
    if mode == 'deletion-no-timestamp': operation['completedAt'] = None
    print(json.dumps({'operation': operation}))
elif cmd == "list":
    import datetime
    expiry = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=2)
    print(json.dumps({"sandboxes": [{"id": vm.name, "status": "running", "type": "default",
          "name": "factory: G11 review — synthetic", "archiveAfter": expiry.isoformat()}
          for vm in root.glob("vm-*") if not (vm / "deleted").exists()]}))
else: sys.exit("unexpected fake boat command " + cmd)
'''


def main():
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="launch-guards-test-") as directory:
        base = pathlib.Path(directory)
        bench = base / "bench"
        for f in (*worker_files(ROOT), "harbor/responder/responder.py", "harbor/responder/ask-human",
                  "bin/exam-launch", "bin/boat-spend"):
            dest = bench / f
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / f, dest)
        # Inject only the clock into the temporary executable; run its real main
        # and process owner, including deadlines, killing and exit status 124.
        shutil.copy2(_Path(__file__).with_name('launch_guard_clock.py'), bench / 'bin/launch_guard_clock.py')
        boat_call = bench / 'bin/boat-call'
        source = boat_call.read_text()
        assert source.count('import processes\n') == 1, 'boat-call clock seam moved'
        boat_call.write_text(source.replace('import processes\n',
            'import processes\nimport launch_guard_clock\nlaunch_guard_clock.install(processes)\n'))
        (bench / "sealed").mkdir()
        # A throwaway age key and an encrypted fake bundle, shaped like bin/setup-secrets output.
        identity = base / "identity.txt"
        subprocess.run(["age-keygen", "-o", str(identity)], check=True, capture_output=True)
        recipient = subprocess.check_output(["age-keygen", "-y", str(identity)], text=True).strip()
        # This isolated bench belongs to the throwaway identity. Keep the real
        # founder-identity check active, with its public recipient set to our key.
        import re
        runner = bench / "factory/run.py"
        runner_source, replacements = re.subn(r'^FOUNDER_RECIPIENT = "age1[a-z0-9]+"',
            'FOUNDER_RECIPIENT = "' + recipient + '"', runner.read_text(), flags=re.M)
        assert replacements == 1
        runner.write_text(runner_source)
        plain = base / "plain"; plain.mkdir()
        for name in ("claude-token", "claude-token-2", "codex-auth.json", "openrouter-key", "opencode-go-key", "statements-key"):
            (plain / name).write_text("fake-" + name + "\n")
        (plain / 'codex-auth.json').write_text(json.dumps({
            'tokens': {'access_token':'e30.eyJleHAiOjQxMDI0NDQ4MDB9.synthetic'},
            'last_refresh':'2026-10-28T00:00:00Z'}))
        bundle_file = base / "secrets.age"
        tar = subprocess.run(["tar", "-C", str(plain), "-cf", "-", "claude-token", "claude-token-2", "codex-auth.json", "openrouter-key", "opencode-go-key", "statements-key"],
                             check=True, capture_output=True).stdout
        subprocess.run(["age", "-r", recipient, "-o", str(bundle_file)], input=tar, check=True)
        IDENTITY = identity.read_text()
        (bench / "sealed/test.tar.gz.age").write_text("encrypted fixture")
        sys.path.insert(0, str(bench / "factory"))
        from exam_responder import contract
        from sealed_audit import delivery_contract
        reviewer = {"model": "synthetic/reviewer", "effort": "high"}
        (bench / "sealed/test.scorecard.json").write_text(json.dumps(
            {"case": "test", "sha256": "a" * 64, "roles": {"reviewer": reviewer}, "owner_contract": contract(bench, reviewer),
             "delivery_provenance": {"contract": delivery_contract(), "sha256": "b" * 64}, "gates": {f"G{i}": "pass" for i in range(1, 18)}}))
        # Use the real registry and age format for the advisory selection board.
        from registry import Registry
        statement = bench / "sealed/case-old.statement.age"
        subprocess.run(["age", "-r", recipient, "-o", str(statement)],
                       input=b"synthetic old statement", check=True)
        Registry(bench / "sealed/statement-registry").import_historical("case-old", statement)
        import hashlib
        statement_sha = hashlib.sha256(statement.read_bytes()).hexdigest()
        fake = base / "fake-boat"
        fake.write_text(FAKE); fake.chmod(0o755)
        # Advance only the retry test's host clock. No production retry/backoff is shortened.
        clockbin = base / "clockbin"; clockbin.mkdir()
        clock = clockbin / "date"
        clock.write_text('#!/usr/bin/env python3\nimport os,pathlib,subprocess,sys,time\n'
                         'if sys.argv[1:]==["+%s"]:\n'
                         ' p=pathlib.Path(os.environ["FAKE_STATE"])/"clock"\n'
                         ' n=int(p.read_text())+75 if p.exists() else int(time.time())\n'
                         ' p.write_text(str(n)); print(n)\n'
                         'else: sys.exit(subprocess.run(["/bin/date",*sys.argv[1:]]).returncode)\n')
        clock.chmod(0o755)
        # Any accidental call to naming is a hard failure, even though BOAT_CMD should skip it.
        (bench / "bin/boat-name").write_text("#!/bin/sh\necho UNEXPECTED_NAMING_CALL >&2\nexit 99\n")
        (bench / "bin/boat-name").chmod(0o755)
        # Isolated retirement seam: no launcher, case or credentials; receipts survive cleanup.
        for mode in ('finish', 'deletion-wrong-worker', 'deletion-wrong-operation',
                     'deletion-wrong-kind', 'deletion-incomplete', 'deletion-wrong-stage',
                     'deletion-no-timestamp', 'deletion-unavailable'):
            cloud = base / ('receipt-' + mode); (cloud / 'vm-1').mkdir(parents=True)
            temporary = cloud / 'temporary'; temporary.mkdir()
            (temporary / 'ids').write_text('vm-1\n')
            spend = cloud / 'spend.json'; spend.write_text('{}')
            script = r'''root=$1; state=$2; spend_file=$3; label=exam
. "$root/bin/boat-launch-guards.sh"
collect_vm() { touch "$state/$1.collected"; }
guard_retire vm-1
status=$?
# A second retirement (as from guard_exit) must not issue another deletion.
guard_retire vm-1 >/dev/null 2>&1
rm -rf "$state"
exit "$status"
'''
            result = subprocess.run(['/bin/sh', '-c', script, 'sh', str(bench),
                                     str(temporary), str(spend)], capture_output=True, text=True,
                                    timeout=HANG_GUARD_SECONDS, env=dict(os.environ, UNBUG_CLOUD='boat',
                                    BOAT_CMD=str(fake), FAKE_STATE=str(cloud), FAKE_MODE=mode,
                                    # Only the never-completing operation should reach the deadline.
                                    **({'BOAT_DELETION_TIMEOUT_SECONDS': '10'} if mode == 'deletion-incomplete' else {})))
            evidence = spend.with_suffix('.deletions') / 'vm-1'
            assert not temporary.exists()
            assert (evidence / 'deletion-request.json').exists(), (mode, result.returncode, result.stderr)
            request = json.loads((evidence / 'deletion-request.json').read_text())
            assert request['id'] == 'op-vm-1' and request['targetId'] == 'vm-1'
            assert 'must not persist' not in (evidence / 'deletion-request.json').read_text()
            completion = evidence / 'deletion-completion.json'
            assert completion.exists() == (mode == 'finish'), (mode, result.stderr)
            if mode == 'finish':
                verified = json.loads(completion.read_text())
                assert result.returncode == 0 and verified == dict(id='op-vm-1', targetId='vm-1',
                    kind='sandbox', status='completed', stage='completed', completedAt='2026-10-22T22:00:00Z')
            else:
                assert result.returncode != 0 and 'verification FAILED' in result.stderr
            calls = [json.loads(line) for line in (cloud / 'calls').read_text().splitlines()]
            assert len([c for c in calls if c[0] == 'delete']) == 1
            assert calls[0] == ['delete', 'vm-1', '--yes', '--json']
            assert all(c == ['deletion', 'status', 'op-vm-1', '--json'] for c in calls[1:])
        print('PASS durable deletion receipts; exact identity/completion, bounded polling, no deletion resubmission')
        counter = 0

        def code_ok(proc): return proc.returncode == 0

        def run(kind="factory", mode="finish", extra=(), count=1, sig=None, **overrides):
            nonlocal counter
            counter += 1
            state = base / f"state-{counter}"
            state.mkdir()
            # Independent synthetic scenarios have independent accounting homes.
            # Cross-launch liability/replay is exercised in test_isolation_timeouts.
            env = dict(os.environ, BOAT_CMD=str(fake), FAKE_STATE=str(state), FAKE_MODE=mode, FAKE_STATEMENT_SHA=statement_sha, UNBUG_CONTROL_HOME=str(base / f"control-{counter}"),
                       BOAT_POLL_SECONDS="0.1", BOAT_STALL_MINUTES="0.02",
                       BOAT_UNREACHABLE_SECONDS="1", BOAT_COMMAND_TIMEOUT_SECONDS="2", BOAT_COLLECT_RETRY_SECONDS="0", UNBUG_SECRETS_FILE=str(bundle_file), FAKE_IDENTITY=str(identity), FAKE_PERMISSION_HELPER=str(bench / "factory/case_permissions.py"))
            env.update(overrides)
            if sig: env['FAKE_SIGNAL'] = str(sig)
            if mode.startswith("reuse-"):
                env['UNBUG_CLOUD'] = 'boat'
                vm = state / 'vm-existing'; (vm / 'factory').mkdir(parents=True)
                (vm / 'sealed').mkdir(); (vm / 'work/case-synthetic/case').mkdir(parents=True)
                sha = 'b' * 64 if mode == 'reuse-bench-changed' else 'a' * 64
                (vm / 'factory/run.py').write_text(f'def bench_manifest(): return {sha!r}\n')
                if mode == 'reuse-advanced-ledger':
                    (vm / 'sealed/case-synthetic.continuation-budget.json').write_text(json.dumps({'cost': .33, 'calls': 50}))
                if mode == 'reuse-locked': (vm / 'sealed/.factory-review-restore.lock').mkdir()
                if mode == 'reuse-audit-present':
                    audit = vm / 'work/case-synthetic/g11-audit'; audit.mkdir()
                    (audit / 'notes.txt').write_text('newer notes that must survive')
                # The fake VM must not see the host's real Codex agent process.
                processbin = vm / 'processbin'; processbin.mkdir()
                (processbin / 'pgrep').write_text('#!/bin/sh\nexit '+('0' if mode == 'reuse-runner' else '1')+'\n')
                if mode in ('reuse-tar', 'reuse-model'):
                    pattern = 'tar -x' if mode == 'reuse-tar' else 'opencode'
                    (processbin / 'pgrep').write_text('#!/bin/sh\ncase "$*" in *"'+pattern+'"*) exit 0;; *) exit 1;; esac\n')
                (processbin / 'pgrep').chmod(0o755)
                env['PATH'] = str(processbin) + os.pathsep + env['PATH']
            if mode.startswith("autoretry"):
                env.update(UNBUG_CLOUD="boat", PATH=str(clockbin)+os.pathsep+env["PATH"])
            cmd = ["/bin/sh", str(bench / "factory/launch.sh"), str(count), "--source", "port"] if kind == "factory" else [
                "/bin/sh", str(bench / "bin/exam-launch"), str(bench / "sealed/test.tar.gz.age"), "--arm", "A"]
            if sig:
                # exec preserves the launcher PID; pressure stdout as well as
                # the fake transport's stderr before any readiness event.
                cmd = [sys.executable, '-c', "import os,sys,signal; signal.signal(signal.SIGINT, signal.SIG_DFL); print('synthetic startup output\\n'*16384, end='', flush=True); os.execv(sys.argv[1], sys.argv[1:])", *cmd]
            before = set((bench / "results/spend").glob("*.json"))
            # Shell background jobs inherit ignored SIGINT. Reproduce that entry
            # state even in foreground runs; the exec wrapper must reset it before
            # /bin/sh starts, since a shell cannot trap an inherited ignored INT.
            previous_int = signal.signal(signal.SIGINT, signal.SIG_IGN) if sig else None
            try:
                proc = subprocess.Popen(cmd + list(extra), env=env, stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                                        start_new_session=True)
            finally:
                if sig: signal.signal(signal.SIGINT, previous_int)
            # Publish before communicate releases stdin and the stdout prelude.
            (state / 'launcher.pid').write_text(str(proc.pid))
            try:
                out, err = proc.communicate(IDENTITY, timeout=HANG_GUARD_SECONDS)
            except subprocess.TimeoutExpired:
                # Never leave a failed synthetic controller running after
                # its temporary fixture is removed.
                os.killpg(proc.pid, signal.SIGKILL)
                out, err = proc.communicate()
                raise AssertionError("synthetic launcher timed out: " + err)
            if sig:
                assert list(state.glob('vm-*/polled')) and (state / 'signal-sent').exists(), err
                assert err.count('synthetic setup diagnostics') == 16384, 'setup output was not drained'
                assert out.count('synthetic startup output') == 16384, 'startup output was not drained'
            calls = [json.loads(line) for line in (state / "calls").read_text().splitlines()] if (state / "calls").exists() else []
            records = set((bench / "results/spend").glob("*.json")) - before
            record = json.loads(next(iter(records)).read_text()) if records else None
            assert "UNEXPECTED_NAMING_CALL" not in err, err
            ids = [vm.name for vm in state.glob("vm-*")]
            events = [json.loads(line) for line in (state / 'clock-events').read_text().splitlines()] if (state / 'clock-events').exists() else []
            assert all(pathlib.Path(e['event']).with_suffix('.observed').exists() for e in events), events
            if mode in ('unreachable', 'hang'):
                assert record, 'live-worker retention must retain its spend record'
                assert any(c[0] == 'exec' for c in calls), ('runner never started', err)
                assert all((state / id / 'polled').exists() for id in ids), ('watchdog never reached', err)
                assert 'collect failed for' in err and 'KEEPING it running' in err, err
                if mode == 'hang':
                    assert 'boat-call: command timed out' in err, err
                    assert any('.boat-launch-start' in e['args'][-1] for e in events), events
                    assert any('hashlib' in e['args'][-1] for e in events), events
            if mode == 'setup-timeout':
                assert len(events) == 1 and '.statements-stage-' in events[0]['args'][-1], events
            if overrides.get('FAKE_RESTORE_ELAPSED'):
                assert len(events) == 1 and events[0]['seconds'] == 1, events
            rejected_reuse = mode.startswith('reuse-') and not any(c[0] == 'exec' for c in calls)
            if mode != "delete-fail":
                assert rejected_reuse or mode in ("collect-fail", "autoretry-corrupt", "autoretry-nohash", "autoretry-uncertain", "unreachable", "hang") or all((state / id / "deleted").exists() for id in ids), (cmd, err)
            for id in ids:
                if rejected_reuse or mode in ("collect-fail", "autoretry-corrupt", "autoretry-nohash", "autoretry-uncertain", "unreachable", "hang"):  # uncertain artifacts never permit deletion
                    assert not any(call[:2] == ["delete", id] for call in calls), err; continue
                deletion = next(i for i, call in enumerate(calls) if call[:2] == ["delete", id])
                assert any(call[:2] == ["ssh", id] and "ls *." in call[2] for call in calls[:deletion]), err
            if mode == "finish" and code_ok(proc):
                assert ids and all((state / id / "secrets-ok").exists() for id in ids), err
            if record:
                retained = any(not (state / id / "deleted").exists() for id in ids)
                if retained and not rejected_reuse:
                    assert mode in ("collect-fail", "autoretry-corrupt", "autoretry-nohash", "autoretry-uncertain", "unreachable", "hang", "delete-fail"), (mode, err)
                    assert "!!! ORPHAN:" in err, err
                if retained and not rejected_reuse:
                    # Durable factory launches remain open until retirement;
                    # all launch kinds retain reservations for uncertain live workers.
                    assert record["balance_after_usd"] is None and record["actual_spend_usd"] is None, (record, err)
                    assert "Actual spend" not in err
                else:
                    assert record["balance_after_usd"] is not None, (record, err)
                    assert "Account observation" in err
            return proc.returncode, out, err, calls, record

        exam_card = bench / "sealed/test.scorecard.json"
        qualified = exam_card.read_text()
        legacy = json.loads(qualified); legacy["gates"].pop("G16")
        exam_card.write_text(json.dumps(legacy))
        code, _, _, calls, _ = run("exam")
        assert code != 0 and not calls, "unqualified cases must fail before any cloud action"
        exam_card.write_text(qualified)
        for kind, hours in (("factory", 8), ("exam", 2.5)):
            code, out, err, calls, rec = run(kind)
            assert code == 0, err
            if kind == "factory": assert (bench / "sealed/result.statement.age").is_file()
            assert rec["ttl_seconds"] == hours * 3600
            assert rec["actual_spend_usd"] is None
            assert abs(rec["account_balance_delta_usd"] - 0.001) < 1e-9
            assert "TTL-priced estimate admitted; not a hard billing ceiling" in err
        code, _, err, _, rec = run("exam", extra=("--arm", "C", "--tries", "2"))
        assert code == 0 and rec["ttl_seconds"] == 7 * 3600, err
        code, _, err, _, rec = run("exam", extra=("--ttl-hours", "0.5"))
        assert code == 0 and rec["ttl_seconds"] == 1800, err
        print("PASS TTL defaults, arm/try sizing, override, collection and spend records")

        # Real age/tar streaming through the actual launcher, with a fake cloud only.
        import hashlib
        audit = base / "audit/g11-audit"; (audit / "case").mkdir(parents=True)
        (audit / "case/promise.md").write_text("synthetic case")
        (audit / "notes.txt").write_text("saved review notes")
        archive = bench / "sealed/g11-review-case-synthetic.tar.gz.age"
        case_identity = base / 'case-identity'
        subprocess.run(['age-keygen', '-o', str(case_identity)], check=True, capture_output=True)
        case_recipient = subprocess.check_output(['age-keygen', '-y', str(case_identity)], text=True).strip()
        wrapped = bench / 'sealed/g11-review-case-synthetic.casekey.age'
        subprocess.run(['age', '-r', recipient, '-o', str(wrapped), str(case_identity)], check=True)
        tar = subprocess.run(["tar", "-C", str(audit.parent), "-czf", "-", audit.name], check=True, capture_output=True).stdout
        subprocess.run(["age", "-r", case_recipient, "-o", str(archive)], input=tar, check=True)
        card = {"case": "case-synthetic", "kind": "g11-independent-review", "status": "stopped", "inputs_unchanged": True, "digest_version": 2,
                "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "continuation_budget": {"cost": .32, "calls": 49},
                "review_bench_sha256": 'a' * 64}
        public = bench / "sealed/g11-review-case-synthetic.scorecard.json"; public.write_text(json.dumps(card))
        code, out, err, calls, rec = run(extra=("--restore-review", "case-synthetic"))
        assert code == 0, err
        assert any(c[0] == "exec" and "'--continue-g11-review'" in c[-1] for c in calls), err
        assert not list((bench / "sealed").glob("g11-audit")), "restore must not decrypt into host sealed/"
        keyed_archive = archive.read_bytes()
        wrapped.rename(wrapped.with_suffix('.missing'))
        archive.unlink()
        subprocess.run(['age', '-r', recipient, '-o', str(archive)], input=tar, check=True)
        card['sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest(); public.write_text(json.dumps(card))
        code, _, err, calls, _ = run(extra=("--restore-review", "case-synthetic"))
        assert code == 0, 'legacy unwrapped audit must remain restorable: ' + err
        wrapped.with_suffix('.missing').rename(wrapped)
        archive.write_bytes(keyed_archive)
        card['sha256'] = hashlib.sha256(keyed_archive).hexdigest(); public.write_text(json.dumps(card))
        card["digest_version"] = 1; public.write_text(json.dumps(card))
        code, _, err, calls, _ = run(extra=("--restore-review", "case-synthetic"))
        assert code != 0 and not calls and "retired" in err, "old audit generations must stop before VM creation"
        card["digest_version"] = 2; public.write_text(json.dumps(card))
        code, _, err, calls, _ = run(extra=("--restore-review", "case-synthetic"),
            BOAT_COMMAND_TIMEOUT_SECONDS='0.5', BOAT_RESTORE_TIMEOUT_SECONDS='3',
            FAKE_EXPECT_RESTORE_TIMEOUT='3', FAKE_RESTORE_ELAPSED='1')
        assert code == 0, err
        reuse = ('--restore-review', 'case-synthetic', '--reuse-review-worker', 'vm-existing')
        code, _, err, calls, rec = run(mode='reuse-review', extra=reuse)
        assert code == 0, err
        assert not any(c[0] in ('new', 'ttl') for c in calls), 'recovery must preserve the existing VM and provider expiry'
        assert 3600 < rec['ttl_seconds'] <= 7200
        assert len([c for c in calls if c[0] == 'exec']) == 1
        for mode in ('reuse-advanced-ledger', 'reuse-bench-changed', 'reuse-locked', 'reuse-runner', 'reuse-audit-present', 'reuse-tar', 'reuse-model'):
            code, _, err, calls, _ = run(mode=mode, extra=reuse)
            assert code != 0, (mode, err)
            assert not any(c[0] in ('new', 'exec', 'scp', 'delete') for c in calls), (mode, err)
        print('PASS slow archive streams use their own timeout; same-VM recovery keeps expiry and rejects active, locked or changed work without taking ownership')
        card["sha256"] = "0" * 64; public.write_text(json.dumps(card))
        code, _, err, calls, rec = run(extra=("--restore-review", "case-synthetic"))
        assert code != 0 and not calls, "corrupt audit must stop before creating or billing a VM"
        print("PASS review continuation streams prior notes to the right VM path, preserves usage and rejects corrupt archives before VM creation")
        if '--restore-only' in sys.argv[1:]:
            print('All restore checks passed; no real boat calls.')
            return

        code, _, err, _, _ = run("exam", EXAM_CLAUDE_SECRET="claude-token-2")
        assert code == 0, err
        print("PASS account 2 reaches canonical claude-token in VM RAM")

        code, _, err, calls, _ = run(mode='qualification-fail')
        assert code != 0 and 'worker release qualification failed' in err
        assert not any(c[0] == 'exec' or (c[0] == 'ssh' and 'base64 -d | tar' in c[2]) for c in calls)
        print('PASS worker release qualification failure precedes secrets and model work')

        code, _, err, calls, _ = run(mode='image-fail')
        assert code != 0 and 'Medusa image preparation failed before credentials' in err
        assert not any(c[0] == 'exec' or (c[0] == 'ssh' and
            ('base64 -d | tar' in c[2] or 'factory/worker_release.py' in c[2])) for c in calls)
        print('PASS Medusa image fallback precedes qualification; build failure prevents credentials and model work')

        for version in ("1.19.0", "1.19.3"):
            code, _, err, calls, _ = run(FAKE_OPENCODE_VERSION=version)
            assert code == 0, err
            vm = base / f"state-{counter}/vm-1"
            assert (vm / "opencode-installed").exists() == (version != "1.19.0")
            preflight = next(i for i,c in enumerate(calls) if c[0] == "ssh" and "--version" in c[2])
            secret = next(i for i,c in enumerate(calls) if c[0] == "ssh" and "base64 -d | tar" in c[2])
            assert preflight < secret
        for mode in ("pin-install-fail", "pin-wrong-version"):
            code, _, err, calls, _ = run(mode=mode, FAKE_OPENCODE_VERSION="1.19.3")
            assert code != 0, err
            assert not any(c[0] == "exec" or c[0] == "ssh" and "base64 -d | tar" in c[2] for c in calls)
        print("PASS absolute OpenCode pin repairs drift before secrets, disables updates and fails closed")
        code, _, err, calls, _ = run(FAKE_CODEX_VERSION="0.163.0")
        assert code == 0, err
        assert (base / f"state-{counter}/vm-1/codex-installed").exists()
        for mode in ("codex-pin-install-fail", "codex-pin-wrong-version"):
            code, _, err, calls, _ = run(mode=mode, FAKE_CODEX_VERSION="0.163.0")
            assert code != 0, err
            assert not any(c[0] == "exec" or c[0] == "ssh" and "base64 -d | tar" in c[2] for c in calls)
        print("PASS Codex drift is repaired before secrets; wrong or failed pins stop before work")

        for mode, expected in (("autoretry", 4), ("autoretry-gate", 1), ("autoretry-cap", 1), ("autoretry-corrupt", 1), ("autoretry-nohash", 1), ("autoretry-uncertain", 2)):
            code, _, err, calls, _ = run(mode=mode, extra=("--max-total-calls", "700", "--max-cost", "2"), BOAT_COLLECT_RETRY_SECONDS="0")
            starts = [c for c in calls if c[0] == "exec"]
            assert len(starts) == expected, (mode, err, starts)
            assert len([c for c in calls if c[0] == "new"]) == 1
            assert not any(c[0] == "ttl" for c in calls)
            assert code == (1 if mode in ("autoretry-corrupt", "autoretry-nohash", "autoretry-uncertain") else 0), (mode, err)
            if mode == "autoretry-uncertain":
                assert "detached restart outcome is uncertain" in err
                assert (bench / "sealed/case-synthetic.checkpoint.tar.gz.age").read_bytes() == b"new uncertain checkpoint"
            if expected == 4:
                assert "retry 3/3" in err and "three restart attempts exhausted" in err, err
                for start in starts[1:]:
                    idx = calls.index(start)
                    assert any(c[0] == "ssh" and "case-synthetic.checkpoint" in c[2] and "hashlib.sha256()" in c[2] for c in calls[:idx])
        print("PASS Boat retries: three attempts, checkpoint verification, preserved ceilings and seed, no gate/cap/corruption retry")

        wrong = base / "wrong.txt"
        subprocess.run(["age-keygen", "-o", str(wrong)], check=True, capture_output=True)
        for kind in ("factory", "exam"):
            saved, IDENTITY = IDENTITY, wrong.read_text()
            code, _, err, calls, _ = run(kind)
            IDENTITY = saved
            assert code != 0 and "could not decrypt" in err and not any(c[0] == "new" for c in calls), err
        print("PASS keys decrypt in memory, reach every VM; a wrong identity stops before any VM")

        for options in ({"extra": ("--max-spend", "0.01")}, {"FAKE_BALANCE": "1"}, {"count": 21}):
            code, _, err, calls, rec = run(**options)
            assert code != 0 and not any(c[0] == "new" for c in calls), err
            assert rec and not rec["allowed"]
        for options in ({"mode": "bad-billing"}, {"extra": ("--ttl-hours", "NaN")},
                        {"extra": ("--max-spend", "-1")}, {"BOAT_STALL_MINUTES": "0"}):
            code, _, err, calls, _ = run(**options)
            assert code != 0 and not any(c[0] == "new" for c in calls), err
        print("PASS spend cap, balance, malformed billing and invalid options fail closed")

        for kind in ("factory", "exam"):
            code, _, err, _, _ = run(kind, "stale")
            assert code != 0 and "STALLED: no progress for 0.02 min" in err, err
            extra = ("--out", "~/exam-out", "--private=~/exam-private") if kind == "exam" else ()
            code, _, err, calls, _ = run(kind, "progress", extra=extra, BOAT_POLL_SECONDS="0.4", BOAT_STALL_MINUTES="0.016")
            assert code == 0 and "STALLED" not in err, err
            if kind == "exam":
                assert any(c[0] == "exec" and "'--out' '/home/user/exam-out'" in c[-1]
                           and "'--private' '/home/user/exam-private'" in c[-1] for c in calls), err
        code, _, err, calls, _ = run(mode='startup-crash')
        assert code != 0 and 'runner startup failed' in err and 'STALLED' not in err, err
        receipt = json.loads((bench / 'sealed/vm-1.runner-status.json').read_text())
        assert receipt['reason'] == 'startup_failed' and receipt['exit_status'] == 1
        code, _, err, calls, _ = run(mode='containment-unavailable')
        assert code != 0 and 'runner startup failed' in err and 'STALLED' not in err, err
        receipt = json.loads((bench / 'sealed/vm-1.runner-status.json').read_text())
        assert (receipt['attempt'], receipt['phase'], receipt['reason'], receipt['exit_status']) == (
            0, 'startup', 'containment_unavailable', 78)
        print('PASS detached startup exit receipt is promptly collected without a case DONE')
        # The failed second setup must return to monitoring the healthy first worker.
        real = json.loads((ROOT / 'tests/factory/fixtures/isolation-timeouts/monitor.json').read_text())
        code, _, err, calls, _ = run(mode='second-qualification-fail', count=2,
            extra=('--ttl-hours', str(real['ttl_seconds'] / 3600), '--max-spend', '2'))
        assert code != 0 and 'setup failed' in err, err
        last_failure = max(i for i,c in enumerate(calls) if c[:2] == ['ssh','vm-2'] and 'factory/worker_release.py' in c[2])
        healthy_delete = next(i for i,c in enumerate(calls) if c[:2] == ['delete','vm-1'])
        assert any(c[:2] == ['ssh','vm-1'] and 'STARTUP_FAILED' in c[2]
                   for c in calls[last_failure+1:healthy_delete]), err
        assert not any(c[:2] == ['exec','vm-2'] for c in calls), err
        print('PASS real-TTL worker setup failure leaves healthy peer under its own monitor')
        code, _, err, calls, _ = run(mode="mixed", count=2)
        assert code != 0 and "STALLED" in err, err
        deletes = [c[1] for c in calls if c[0] == "delete"]
        assert sorted(deletes) == ["vm-1", "vm-2"], deletes
        print("PASS stale watchdog, live ledger/job progress and independent batch polling")

        for kind in ("factory", "exam"):
            for mode in ("setup-fail", "new-fail", "collect-fail"):
                code, _, err, _, _ = run(kind, mode, BOAT_COLLECT_RETRY_SECONDS="0")
                assert code != 0, (kind, mode, err)
                if mode == "collect-fail": assert "KEEPING it running" in err and "deleted vm-" not in err, err
            for sig in (signal.SIGINT, signal.SIGTERM):
                code, _, err, _, _ = run(kind, "stall", sig=sig, BOAT_STALL_MINUTES="20")
                assert code == 128 + sig, err
        print("PASS setup/create/collect failures, Ctrl-C and TERM always collect before delete")

        code, _, err, calls, _ = run(mode='setup-timeout', BOAT_COMMAND_TIMEOUT_SECONDS='1')
        assert code != 0 and 'boat-call: command timed out' in err and 'setup failed' in err, err
        assert not any(c[0] == 'exec' for c in calls), 'setup timeout must precede runner start'
        assert any(c[0] == 'delete' for c in calls), 'verified empty worker should retire'
        for mode in ("unreachable", "hang"):
            code, _, err, _, _ = run(mode=mode, **({'BOAT_COMMAND_TIMEOUT_SECONDS': '1'} if mode == 'hang' else {}))
            assert code != 0 and "UNREACHABLE" in err, err
        code, _, err, _, _ = run(mode="delete-fail")
        assert code != 0 and "!!! ORPHAN: vm-1 STILL ALIVE" in err, err
        print("PASS failed/hung SSH cutoff, deletion retry and loud orphan warning")

        # Exercise quoting with apostrophes without executing any user text locally.
        value = "hello 'world'; $(false)"
        quoted = subprocess.check_output(["/bin/sh", "-c", '. "$1"; quote "$2"', "sh",
                                          str(bench / "bin/boat-launch-guards.sh"), value], text=True)
        assert shlex.split(quoted) == [value], quoted
        env = dict(os.environ, BOAT_CMD=str(fake), FAKE_STATE=str(base), FAKE_BALANCE="123456",
                   UNBUG_CONTROL_HOME=str(base / "standalone-control"))
        assert subprocess.check_output([str(bench / "bin/boat-spend")], env=env, text=True).strip() == "1.23456"
        # The cap prices the machine size: 10 large VMs for 2 h = $1.44 must exceed a $1 cap (2026-10-18).
        big = subprocess.run([str(bench / "bin/boat-spend"), "--check", "10", "2", "1", str(base / "cap.json")],
                             env=dict(env, BOAT_TYPE="large"), capture_output=True, text=True)
        assert big.returncode != 0 and "estimated batch cost exceeds balance or --max-spend" in big.stderr, big.stderr
        assert json.loads((base / "cap.json").read_text())["estimated_usd"] == 1.44
        print("PASS argument quoting, standalone dollars-left command, size-priced cap")
    print(f"All launch guard checks passed ({time.monotonic() - started:.1f}s); no real boat calls.")


if __name__ == "__main__":
    main()
